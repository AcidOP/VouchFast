const links = [
  {
    url: '/',
    label: 'Home',
  },
  {
    url: '/#features',
    label: 'Features',
  },
  {
    url: '/#pricing',
    label: 'Pricing',
  },
  {
    url: '/#faq',
    label: 'FAQ',
  },
  {
    url: '/contact',
    label: 'Contact',
  },
  // {
  //   url: '',
  //   label: '',
  // }
];

export default links;
