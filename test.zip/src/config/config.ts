export const siteConfig = {
  API_KEY_TOKEN_NAME: 'Api-Key',
  API_KEY_REGEX: /^vf_[a-zA-Z0-9]{30}$/,
  twitter: 'https://x.com/whynotacid',
  email: 'acid@acidop.codes',
};
