import Hero from './homepage';

export default Hero;
