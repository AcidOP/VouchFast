import Testimonials from './testimonials';

export default Testimonials;
