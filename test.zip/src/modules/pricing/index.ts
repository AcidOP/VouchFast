import Pricing from './pricing-page';

export default Pricing;
