import Faq from './faq';

export default Faq;
