import ProductBox from './product-box';

export default ProductBox;
