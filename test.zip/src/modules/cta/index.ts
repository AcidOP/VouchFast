import CTA from './cta';

export default CTA;
