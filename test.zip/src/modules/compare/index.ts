import Compare from './compare';

export default Compare;
